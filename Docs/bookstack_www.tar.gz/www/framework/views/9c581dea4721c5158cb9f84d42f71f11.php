<div components="dropdown dropdown-search"
     option:dropdown-search:url="/search/entity/siblings?entity_type=<?php echo e($entity->getType()); ?>&entity_id=<?php echo e($entity->id); ?>"
     option:dropdown-search:local-search-selector=".entity-list-item"
     class="dropdown-search">
    <button class="dropdown-search-toggle-breadcrumb"
            refs="dropdown@toggle"
            aria-haspopup="true"
            aria-expanded="false"
            title="<?php echo e(trans('entities.breadcrumb_siblings_for_' . $entity->getType())); ?>">
        <div role="presentation" class="separator"><?php echo (new \BookStack\Util\SvgIcon('chevron-right'))->toHtml(); ?></div>
    </button>
    <div refs="dropdown@menu" class="dropdown-search-dropdown card">
        <div class="dropdown-search-search">
            <?php echo (new \BookStack\Util\SvgIcon('search'))->toHtml(); ?>
            <input refs="dropdown-search@searchInput"
                   aria-label="<?php echo e(trans('common.search')); ?>"
                   autocomplete="off"
                   placeholder="<?php echo e(trans('common.search')); ?>"
                   type="text">
        </div>
        <div refs="dropdown-search@loading">
            <?php echo $__themeViews->handleViewInclude('common.loading-icon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1])); ?>
        </div>
        <div refs="dropdown-search@listContainer" class="dropdown-search-list px-m" tabindex="-1" role="list"></div>
    </div>
</div><?php /**PATH /app/www/resources/views/entities/breadcrumb-listing.blade.php ENDPATH**/ ?>